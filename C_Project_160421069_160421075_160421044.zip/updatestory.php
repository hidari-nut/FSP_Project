<?php
require_once("class/connect.php");
?>
<link rel="stylesheet" href="style.css">
<div class="container">
    <h3>Title</h3> <!--Placeholder for Database query-->
    <div class="story">
        <p>Paragraph 1</p> <!--Placeholder for Database-->
        <p>Paragraph 2</p> <!--Placeholder for Database-->
    </div>
    
    <br>
    <form action="" method="post">
        Tambah Paragraf <br>
        <textarea name="" id="" cols="30" rows="10"></textarea><br><br>
        <input type="submit" name="post" value="Post">
    </form>
</div>